﻿Login-AzureRmAccount

$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Description."
$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","Description."
$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
$rgname = Read-Host -Prompt "Please enter a name for the resource group"

Write-host "1. East Asia"
Write-host "2. Southeast Asia"
Write-host "3. Central US"
Write-host "4. East US"
Write-host "5. East US 2"
Write-host "6. West US"
Write-host "7. North Central US"
Write-host "8. South Central US"
Write-host "9. North Europe"
Write-host "10. West Europe"
Write-host "11. Japan West"
Write-host "12. Japan East"
Write-host "13. Brazil South"
Write-host "14. Canada Central"
Write-host "15. Canada East"
Write-host "16. UK South"
Write-host "17. UK West"
Write-host "18. West Central US"
Write-host "19. West US 2"
$rgloc = read-host "Please select a location..."

switch ($rgloc)
 {
     '1' {
         $rgloc = 'eastasia'
     } '2' {
         $rgloc = 'southeastasia'
     } '3' {
         $rgloc = 'centralus'
     } '4' {
         $rgloc = 'eastus'
     } '5' {
         $rgloc = 'eastus2'
     }'6' {
         $rgloc = 'westus'
     }'7' {
         $rgloc = 'northcentralus'
     }'8' {
         $rgloc = 'southcentralus'
     }'9' {
         $rgloc = 'northeurope'
     }'10' {
         $rgloc = 'westeurope'
     }'11' {
         $rgloc = 'japanwest'
     }'12' {
         $rgloc = 'japaneast'
     }'13' {
         $rgloc = 'brazilsouth'
     }'14' {
         $rgloc = 'canadacentral'
     }'15' {
         $rgloc = 'canadaeast'
     }'16' {
         $rgloc = 'uksouth'
     }'17' {
         $rgloc = 'ukwest'
     }'18' {
         $rgloc = 'westcentralus'
     }'19' {
         $rgloc = 'westus2'
     }
   
 }


 
New-AzureRmResourceGroup -Name $rgname -Location $rgloc




<###################################################################################### 

Provides the option to create and deploy a Storage Account into the same resource group.

#>#####################################################################################

$title = "Storage Account" 
$message = "Do you want to deploy a storage account?"

$result1 = $host.ui.PromptForChoice($title, $message, $options, 1)
switch ($storagequestion) {
    0{
        Write-Host "Yes"
    }1{
        Write-Host "No"
    }
}
if ($result1 -eq 0)
    {
   
    $storagename = Read-Host -Prompt "Please enter a storage account name - all lowercase with no symbols."
    New-AzureRmStorageAccount -ResourceGroupName $rgname -AccountName $storagename -Location $rgloc -Type Standard_GRS
    Get-AzureRmStorageAccount -ResourceGroupName $rgname -Name $storagename | New-AzureStorageContainer -Name "vhds" 
    $storageaccount = get-AzureRmStorageAccount -ResourceGroupName $rgname -Name $storagename 
    
    
    }

   else {
   
   }


<###################################################################################### 

Provides the option to create and deploy a Virtual Network into the same resource group.

#>#####################################################################################


$title = "vNet Deployment" 
$message = "Do you want to deploy a Virtual Network?"
$result2 = $host.ui.PromptForChoice($title, $message, $options, 1)
switch ($vnetquestion) {
    0{
        Write-Host "Yes"
    }1{
        Write-Host "No"
    }
}
if ($result2 -eq 0)
    {
   
    $vNetname = Read-Host -Prompt "Please enter a name for the virtual network"
    $AddressPrefix = Read-Host -Prompt "Please enter the address and cidr in 192.168.1.0/16 format"
    $subnetname = Read-Host -Prompt "Please enter a name for the subnet"
    $subnetprefix = Read-Host -Prompt "Please enter the address and cidr for the subnet based on $AddressPrefix."
    New-AzureRmVirtualNetwork -ResourceGroupName $rgname -Name $vNetname -Location $rgloc -AddressPrefix $AddressPrefix
    $virtnet = Get-AzureRmVirtualNetwork -ResourceGroupName $rgname -Name $vNetname
    Add-AzureRmVirtualNetworkSubnetConfig -Name $subnetname -VirtualNetwork $virtnet -AddressPrefix $subnetprefix
    Set-AzureRmVirtualNetwork -VirtualNetwork $virtnet
    $virtnet = Get-AzureRmVirtualNetwork -ResourceGroupName $rgname -Name $vNetname
    }

   else {
   
   }



<######################################################################################################## 

Provides the option to create and deploy a Virtual Machine into the same resource/storage/network groups.

#>#######################################################################################################

$title = "Virtual Machine Deployment" 
$message = "Do you want to deploy a Virtual Machine?"
$result3 = $host.ui.PromptForChoice($title, $message, $options, 1)
switch ($VMquestion) {
    0{
        Write-Host "Yes"
    }1{
        Write-Host "No"
    }
}
if ($result3 -eq 0)
    {

Write-host "1. A0"
Write-host "2. A1"
Write-host "3. A2"
Write-host "4. A3"
Write-host "5. A4"
Write-host "6. A5"
Write-host "7. A6"
Write-host "8. A7"
Write-host "9. A8"
Write-host "10. A9"
Write-host "11. A10"
Write-host "12. A11"
Write-host "13. D1 V2"
Write-host "14. D2 V2"
Write-host "15. D3 V2"
Write-host "16. D4 V2"
Write-host "17. D5 V2"
Write-host "18. D11 V2"
Write-host "19. D12 V2"
Write-host "20. D13 V2"
Write-host "21. D14 V2"
Write-host "22. D15 V2"
Write-host "23. F1"
Write-host "24. F2"
Write-host "25. F4"
Write-host "26. F8"
Write-host "27. F16"
Write-host "28. DS1 V2"
Write-host "29. DS2 V2"
Write-host "30. DS3 V2"
Write-host "31. DS4 V2"
Write-host "32. DS5 V2"
Write-host "33. DS11 V2"
Write-host "34. DS12 V2"
Write-host "35. DS13 V2"
Write-host "36. DS14 V2"
Write-host "37. DS15 V2"

$vmsize = read-host "Please select a VM size..."

switch ($vmsize)
 {
     '1' {
         $vmsize = 'Standard_A0'
     } '2' {
         $vmsize = 'Standard_A1'
     } '3' {
         $vmsize = 'Standard_A2'
     } '4' {
         $vmsize = 'Standard_A3'
     } '5' {
         $vmsize = 'Standard_A4'
     }'6' {
         $vmsize = 'Standard_A5'
     }'7' {
         $vmsize = 'Standard_A6'
     }'8' {
         $vmsize = 'Standard_A7'
     }'9' {
         $vmsize = 'Standard_A8'
     }'10' {
         $vmsize = 'Standard_A9'
     }'11' {
         $vmsize = 'Standard_A10'
     }'12' {
         $vmsize = 'Standard_A11'
     }'13' {
         $vmsize = 'Standard_D1_v2'
     }'14' {
         $vmsize = 'Standard_D2_v2'
     }'15' {
         $vmsize = 'Standard_D3_v2'
     }'16' {
         $vmsize = 'Standard_D4_v2'
     }'17' {
         $vmsize = 'Standard_D5_v2'
     }'18' {
         $vmsize = 'Standard_D11_v2'
     }'19' {
         $vmsize = 'Standard_D12_v2'
     }'20' {
         $vmsize = 'Standard_D13_v2'
     } '21' {
         $vmsize = 'Standard_D14_v2'
     } '22' {
         $vmsize = 'Standard_D15_v2'
     } '23' {
         $vmsize = 'Standard_F1'
     } '24' {
         $vmsize = 'Standard_F2'
     }'25' {
         $vmsize = 'Standard_F4'
     }'26' {
         $vmsize = 'Standard_F8'
     }'27' {
         $vmsize = 'Standard_F16'
     }'28' {
         $vmsize = 'Standard_DS1_v2'
     }'29' {
         $vmsize = 'Standard_DS2_v2'
     }'30' {
         $vmsize = 'Standard_DS3_v2'
     }'31' {
         $vmsize = 'Standard_DS4_v2'
     }'32' {
         $vmsize = 'Standard_DS5_v2'
     }'33' {
         $vmsize = 'Standard_DS11_v2'
     }'34' {
         $vmsize = 'Standard_DS12_v2'
     }'35' {
         $vmsize = 'Standard_DS13_v2'
     }'36' {
         $vmsize = 'Standard_DS14_v2'
     }'37' {
         $vmsize = 'Standard_DS15_v2'
     }
   
 }

   $vmName = Read-Host -Prompt "Type a name for the virtual machine"
   $ipName = $vmname + "pip"
   $pip = New-AzureRmPublicIpAddress -Name $ipName -ResourceGroupName $rgName -Location $rgloc -AllocationMethod Static
   $nicName = $vmname + "nic"
   $nic = New-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $rgName -Location $rgloc -SubnetId $virtnet.Subnets[0].Id -PublicIpAddressId $pip.Id
    
   $localadmin = Get-Credential -Message "Type the username and password of the local admin for the VM. DO NOT USE ADMINISTRATOR"
   $vm = New-AzureRmVMConfig -VMName $vmName -VMSize $vmsize
   $vm = Set-AzureRmVMOperatingSystem -VM $vm -Windows -ComputerName $vmName -Credential $localadmin -ProvisionVMAgent -EnableAutoUpdate
   $vm = Set-AzureRmVMSourceImage -VM $vm -PublisherName MicrosoftWindowsServer -Offer WindowsServer -Skus 2012-R2-Datacenter -Version "latest"
   $vm = Add-AzureRmVMNetworkInterface -VM $vm -Id $nic.Id

   $blobPath = "vhds/$($vmName)OSdisk.vhd"
   $osDiskUri = $storageAccount.PrimaryEndpoints.Blob.ToString() + $blobPath
   $diskName = "$($vmName)OSdisk"
   $vm = Set-AzureRmVMOSDisk -VM $vm -Name $diskName -VhdUri $osDiskUri -CreateOption fromImage

   New-AzureRmVM -ResourceGroupName $rgName -Location $rgloc -VM $vm
    }

   else {
   
   }




